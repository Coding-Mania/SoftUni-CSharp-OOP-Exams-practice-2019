﻿using NUnit.Framework;

[TestFixture]
public class ProviderControllerTests
{
    [Test]
    public void Ctor_Should()
    {
        Assert.IsTrue(true);
    }
}
