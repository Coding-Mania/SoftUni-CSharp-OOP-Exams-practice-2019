﻿using System;

namespace TestJudge
{
    public class Class1
    {
    }
}
